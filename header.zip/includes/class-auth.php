<?php
namespace MiCatalogo;

class Auth {
    public function __construct() {
        // Redirigir wp-login.php a nuestra página
        add_action( 'login_init', [ $this, 'redirect_login_page' ] );
        
        // Filtros para cambiar las URLs generadas por WP
        add_filter( 'login_url', [ $this, 'custom_login_url' ], 10, 3 );
        add_filter( 'register_url', [ $this, 'custom_register_url' ] );

        // Procesar envíos de formularios en init
        add_action( 'init', [ $this, 'process_auth_forms' ] );
    }

    public function redirect_login_page() {
        $action = isset( $_REQUEST['action'] ) ? $_REQUEST['action'] : 'login';
        
        // Permitir acciones como logout, recuperar contraseña, etc.
        if ( ! in_array( $action, [ 'logout', 'postpass', 'rp', 'resetpass' ] ) ) {
            wp_redirect( site_url( '/autenticacion/' ) );
            exit;
        }
    }

    public function custom_login_url( $login_url, $redirect, $force_reauth ) {
        return site_url( '/autenticacion/' );
    }

    public function custom_register_url( $register_url ) {
        return site_url( '/autenticacion/?action=register' );
    }

    public function process_auth_forms() {
        // Si no estamos enviando nuestro formulario, salimos
        if ( $_SERVER['REQUEST_METHOD'] !== 'POST' || ! isset( $_POST['micatalogo_auth_nonce'] ) ) {
            return;
        }

        if ( ! wp_verify_nonce( $_POST['micatalogo_auth_nonce'], 'micatalogo_auth_action' ) ) {
            wp_die( 'Petición no válida. Inténtalo de nuevo.' );
        }

        $action = sanitize_text_field( $_POST['auth_action'] );

        if ( $action === 'login' ) {
            $this->process_login();
        } elseif ( $action === 'register' ) {
            $this->process_register();
        }
    }

    private function process_login() {
        $creds = array(
            'user_login'    => sanitize_user( $_POST['email'] ),
            'user_password' => $_POST['password'],
            'remember'      => isset( $_POST['remember'] )
        );

        $user = wp_signon( $creds, is_ssl() );

        if ( is_wp_error( $user ) ) {
            // Guardar el error en un transient o redirigir con un parámetro de error
            wp_redirect( site_url( '/autenticacion/?error=login_failed' ) );
            exit;
        }

        // Login exitoso, redirigir al panel
        wp_redirect( site_url( '/panel-vendedor/' ) );
        exit;
    }

    private function process_register() {
        $email = sanitize_email( $_POST['email'] );
        $password = $_POST['password'];
        $store_name = sanitize_text_field( $_POST['store_name'] );

        if ( empty( $email ) || empty( $password ) || empty( $store_name ) ) {
            wp_redirect( site_url( '/autenticacion/?action=register&error=empty_fields' ) );
            exit;
        }

        if ( email_exists( $email ) || username_exists( $email ) ) {
            wp_redirect( site_url( '/autenticacion/?action=register&error=email_exists' ) );
            exit;
        }

        // Crear el usuario programáticamente (bypasseando la restricción de WP)
        $user_id = wp_insert_user( array(
            'user_login' => $email, // Usamos email como usuario
            'user_pass'  => $password,
            'user_email' => $email,
            'role'       => 'vendor' // Asignar el rol correcto para vendedores
        ) );

        if ( is_wp_error( $user_id ) ) {
            wp_redirect( site_url( '/autenticacion/?action=register&error=creation_failed' ) );
            exit;
        }

        // Guardar el nombre de la tienda
        update_user_meta( $user_id, 'store_name', $store_name );

        // Auto-login al registrar
        wp_set_current_user( $user_id );
        wp_set_auth_cookie( $user_id, true, is_ssl() );

        // Redirigir al Onboarding o Panel
        wp_redirect( site_url( '/panel-vendedor/' ) );
        exit;
    }
}
